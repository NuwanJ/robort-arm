/**
  ******************************************************************************
  * @file	uArmUtils.h
  * @author	David.Long	
  * @email	xiaokun.long@ufactory.cc
  * @date	2017-03-15
  ******************************************************************************
  */

#ifndef _UARMUTILS_H_
#define _UARMUTILS_H_

#include <Arduino.h>
#include "Marlin.h"


#endif // _UARMUTILS_H_
